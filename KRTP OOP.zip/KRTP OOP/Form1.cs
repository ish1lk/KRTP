using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Windows.Forms;

namespace KRTP
{
    public partial class Form1 : Form
    {
        private ClassFigure figure;
        private MonteCarloCalculator monteCarloCalculator;
        private ClassDataHandler dataHandler;

        public Form1()
        {
            InitializeComponent();
            dataHandler = new ClassDataHandler();
        }

        private void Calculate_Click(object sender, EventArgs e)
        {
            if (!dataHandler.ValidateData(textBoxBX.Text, textBoxBY.Text, textBoxDX.Text, textBoxDY.Text, textBoxKX.Text, textBoxKY.Text))
            {
                MessageBox.Show("Incorrect data. Please try again with other values.");
                return;
            }

            figure = new ClassFigure
            {
                BX = Convert.ToDouble(textBoxBX.Text),
                BY = Convert.ToDouble(textBoxBY.Text),
                DX = Convert.ToDouble(textBoxDX.Text),
                DY = Convert.ToDouble(textBoxDY.Text),
                KX = Convert.ToDouble(textBoxKX.Text),
                KY = Convert.ToDouble(textBoxKY.Text)
            };

            monteCarloCalculator = new MonteCarloCalculator(figure);

            double realSquare = figure.SquareReal;
            textBoxSquare.Text = realSquare.ToString("F5");

            // Clear previous rows in DataGridView
            dataGridViewRes.Rows.Clear();

            for (int i = 10, row = 0; i <= 10000000; i *= 10, row++)
            {
                List<double> res = monteCarloCalculator.Calculate(i);

                dataGridViewRes.Rows.Add();
                dataGridViewRes.Rows[row].Cells[0].Value = i;  // Iterations
                dataGridViewRes.Rows[row].Cells[1].Value = res[1];  // Points In Figure
                dataGridViewRes.Rows[row].Cells[2].Value = realSquare.ToString("F5");  // Square Figure
                dataGridViewRes.Rows[row].Cells[3].Value = res[0];  // Monte Carlo Result
                dataGridViewRes.Rows[row].Cells[4].Value = (Math.Abs((realSquare - monteCarloCalculator.SquareFigureMonteCarlo) / realSquare * 100)).ToString("F4");  // Error
                dataGridViewRes.Rows[row].Cells[5].Value = monteCarloCalculator.Time;  // Time
            }
        }

        private void buttonExample_Click(object sender, EventArgs e)
        {
            textBoxBX.Text = "7";
            textBoxBY.Text = "10";
            textBoxDX.Text = "17";
            textBoxDY.Text = "3";
            textBoxKX.Text = "14";
            textBoxKY.Text = "10";
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxBX.Text = "";
            textBoxBY.Text = "";
            textBoxDX.Text = "";
            textBoxDY.Text = "";
            textBoxKX.Text = "";
            textBoxKY.Text = "";
        }

        private void buttonClearX_Click(object sender, EventArgs e)
        {
            textBoxBX.Text = "";
            textBoxDX.Text = "";
            textBoxKX.Text = "";
        }

        private void buttonClearY_Click(object sender, EventArgs e)
        {
            textBoxBY.Text = "";
            textBoxDY.Text = "";
            textBoxKY.Text = "";
        }
    }

}
