﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KRTP
{
    public class ClassFigure {
        public double BX { get; set; }
        public double BY { get; set; }
        public double DX { get; set; }
        public double DY { get; set; }
        public double KX { get; set; }
        public double KY { get; set; }

        public double RadiusCircle => (BY - DY) / 2;
        public double SquareReal => (DX - BX) * (BY - DY) - (Math.PI * RadiusCircle * RadiusCircle) / 2 - (DX - KX) * RadiusCircle;

        public bool IsPointInside(double x, double y)
        {
            return ((x - BX) * (x - BX) + (y - DY - RadiusCircle) * (y - DY - RadiusCircle) >= RadiusCircle * RadiusCircle) &&
                   (y <= -K * x + BTop) && (y >= K * x + BBottom);
        }

        public double K => RadiusCircle / (DX - KX);
        public double BTop => KX * K + KY;
        public double BBottom => KX * (-K) + DY;
    }
}
