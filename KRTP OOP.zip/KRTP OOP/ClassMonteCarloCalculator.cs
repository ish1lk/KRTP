﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KRTP {
        public class MonteCarloCalculator
        {
            private ClassFigure figure;
            private long time;
            private double squareFigureMonteCarlo;

            public MonteCarloCalculator(ClassFigure figure)
            {
                this.figure = figure;
            }

            public List<double>Calculate(int iterations)
            {
                List<double> result = new List<double>();
                Random rnd = new Random();
                double pointsInFigure = 0;
                double squareRect = (figure.DX - figure.BX) * (figure.BY - figure.DY);

                Stopwatch timer = new Stopwatch();
                timer.Restart();
                for (int i = 1; i <= iterations; i++)
                {
                    double randX = figure.BX + rnd.NextDouble() * (figure.DX - figure.BX);
                    double randY = figure.DY + rnd.NextDouble() * (figure.BY - figure.DY);
                    if (figure.IsPointInside(randX, randY)) { pointsInFigure++; }
                }
                timer.Stop();
                time = timer.ElapsedMilliseconds;
                squareFigureMonteCarlo = squareRect * pointsInFigure / iterations;
                result.Add(squareFigureMonteCarlo);
                result.Add(pointsInFigure);
                return result;
            }

            public long Time => time;
            public double SquareFigureMonteCarlo => squareFigureMonteCarlo;
        }

}
