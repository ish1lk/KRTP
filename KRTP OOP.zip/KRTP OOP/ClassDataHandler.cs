﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KRTP
{
    internal class ClassDataHandler {
        public bool ValidateData(string BX, string BY, string DX, string DY, string KX, string KY)
        {
            double tmp;
            return !(string.IsNullOrEmpty(BX) || string.IsNullOrEmpty(BY) || string.IsNullOrEmpty(DX) || string.IsNullOrEmpty(DY)
                || string.IsNullOrEmpty(KX) || string.IsNullOrEmpty(KY)
                || !double.TryParse(BX, out tmp) || !double.TryParse(BY, out tmp) || !double.TryParse(DX, out tmp) || !double.TryParse(DY, out tmp)
                || !double.TryParse(KX, out tmp) || !double.TryParse(KY, out tmp)
                || double.Parse(BX) >= double.Parse(DX) || double.Parse(BY) <= double.Parse(DY)
                || double.Parse(KX) >= double.Parse(DX) || double.Parse(KX) <= double.Parse(BX)
                || double.Parse(KY) <= double.Parse(DY) || double.Parse(KY) != double.Parse(BY));
        }
    }
}
