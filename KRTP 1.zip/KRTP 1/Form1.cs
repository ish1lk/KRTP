using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Windows.Forms;

namespace KRTP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private bool IsCorrectedData()
        {
            double tmp;
            if (
                (textBoxBX.Text == "") ||
                (textBoxBY.Text == "") ||
                (textBoxDX.Text == "") ||
                (textBoxDY.Text == "") ||
                (textBoxKX.Text == "") ||
                (textBoxKY.Text == "") ||
                (Double.TryParse(textBoxBX.Text, out tmp) == false) ||
                (Double.TryParse(textBoxBY.Text, out tmp) == false) ||
                (Double.TryParse(textBoxDX.Text, out tmp) == false) ||
                (Double.TryParse(textBoxDY.Text, out tmp) == false) ||
                (Double.TryParse(textBoxKX.Text, out tmp) == false) ||
                (Double.TryParse(textBoxKY.Text, out tmp) == false) ||
                (double.Parse(textBoxBX.Text) >= double.Parse(textBoxDX.Text)) ||
                (double.Parse(textBoxBY.Text) <= double.Parse(textBoxDY.Text)) ||
                (double.Parse(textBoxKX.Text) >= double.Parse(textBoxDX.Text)) ||
                (double.Parse(textBoxKX.Text) <= double.Parse(textBoxBX.Text)) ||
                (double.Parse(textBoxKY.Text) <= double.Parse(textBoxDY.Text)) ||
                (double.Parse(textBoxKY.Text) != double.Parse(textBoxBY.Text))
            ) { return false; }
            return true;
        }

        private void Example_Click(object sender, EventArgs e)
        {
            textBoxBX.Text = "7";
            textBoxBY.Text = "10";
            textBoxDX.Text = "17";
            textBoxDY.Text = "3";
            textBoxKX.Text = "14";
            textBoxKY.Text = "10";
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            textBoxBX.Text = "";
            textBoxBY.Text = "";
            textBoxDX.Text = "";
            textBoxDY.Text = "";
            textBoxKX.Text = "";
            textBoxKY.Text = "";
        }

        private void buttonClearX_Click(object sender, EventArgs e)
        {
            textBoxBX.Text = "";
            textBoxDX.Text = "";
            textBoxKX.Text = "";
        }

        private void buttonClearY_Click(object sender, EventArgs e)
        {
            textBoxBY.Text = "";
            textBoxDY.Text = "";
            textBoxKY.Text = "";
        }

        static double square_figure_real, radius_circle, Square_Figure_Monte_Karlo;
        static long time;
        static double k, b_top, b_bottom;
        static double BX, BY, DX, DY, KX, KY;

        private void Calculate_Click(object sender, EventArgs e)
        {
            if (IsCorrectedData() == false) { MessageBox.Show("Incorrect data. Please try again with other values."); }
            else
            {
                BX = Convert.ToDouble(textBoxBX.Text);
                BY = Convert.ToDouble(textBoxBY.Text);
                DX = Convert.ToDouble(textBoxDX.Text);
                DY = Convert.ToDouble(textBoxDY.Text);
                KX = Convert.ToDouble(textBoxKX.Text);
                KY = Convert.ToDouble(textBoxKY.Text);

                radius_circle = (BY - DY) / 2;
                square_figure_real = (
                    (DX - BX) * (BY - DY) -
                    (Math.PI * radius_circle * radius_circle) / 2 -
                    (DX - KX) * radius_circle);

                textBoxSquare.Text = Convert.ToString(square_figure_real);

                k = radius_circle / (DX - KX);
                b_top = KX * k + KY;
                b_bottom = KX * (-k) + DY;

                // ������� ���������� ������ � DataGridView
                dataGridViewRes.Rows.Clear();

                for (int i = 10, row = 0; i <= 10000000; i *= 10, row++)
                {
                    List<double> res = Monte_Karlo(i);

                    // ��������� ������ � ������������ � DataGridView
                    dataGridViewRes.Rows.Add();
                    dataGridViewRes.Rows[row].Cells[0].Value = i;  // Iterations
                    dataGridViewRes.Rows[row].Cells[1].Value = res[1];  // Points In Figure
                    dataGridViewRes.Rows[row].Cells[2].Value = square_figure_real.ToString("F" + 5);  // Square Figure
                    dataGridViewRes.Rows[row].Cells[3].Value = res[0];  // Monte Carlo Result
                    dataGridViewRes.Rows[row].Cells[4].Value = (Math.Abs((square_figure_real - Square_Figure_Monte_Karlo) / square_figure_real * 100)).ToString("F" + 4);  // Error
                    dataGridViewRes.Rows[row].Cells[5].Value = time;  // Time
                }
            }
        }

        List<double> Monte_Karlo(int n)
        {
            List<double> answer = new List<double>();
            Random rnd = new Random();
            double randX, randY;
            double pointsInFigure = 0;
            double square_rect = (DX - BX) * (BY - DY);
            Stopwatch timer = new Stopwatch();
            timer.Restart();
            for (int i = 1; i <= n; i++)
            {
                randX = BX + rnd.NextDouble() * (DX - BX);
                randY = DY + rnd.NextDouble() * (BY - DY);
                if (isInFigure(randX, randY)) { pointsInFigure++; }
            }
            timer.Stop();
            time = timer.ElapsedMilliseconds;
            Square_Figure_Monte_Karlo = square_rect * pointsInFigure / n;
            answer.Add(Square_Figure_Monte_Karlo);
            answer.Add(pointsInFigure);
            return answer;
        }

        bool isInFigure(double x, double y)
        {
            return ((x - BX) * (x - BX) + (y - DY - radius_circle) * (y - DY - radius_circle) >= radius_circle * radius_circle) &&
                (y <= -k * x + b_top) && (y >= k * x + b_bottom);
        }

        private void ����������ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
