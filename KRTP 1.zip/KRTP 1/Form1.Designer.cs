﻿namespace KRTP
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            textBoxBX = new TextBox();
            textBoxKX = new TextBox();
            textBoxDX = new TextBox();
            textBoxDY = new TextBox();
            textBoxKY = new TextBox();
            textBoxBY = new TextBox();
            label1 = new Label();
            label2 = new Label();
            buttonExample = new Button();
            buttonCalculate = new Button();
            buttonClear = new Button();
            groupBox1 = new GroupBox();
            label5 = new Label();
            label3 = new Label();
            label4 = new Label();
            groupBox2 = new GroupBox();
            buttonClearY = new Button();
            buttonClearX = new Button();
            dataGridViewRes = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            Column5 = new DataGridViewTextBoxColumn();
            Column6 = new DataGridViewTextBoxColumn();
            textBoxSquare = new TextBox();
            label6 = new Label();
            pictureBox1 = new PictureBox();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewRes).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // textBoxBX
            // 
            textBoxBX.Location = new Point(92, 87);
            textBoxBX.Name = "textBoxBX";
            textBoxBX.Size = new Size(318, 39);
            textBoxBX.TabIndex = 0;
            // 
            // textBoxKX
            // 
            textBoxKX.Location = new Point(92, 163);
            textBoxKX.Name = "textBoxKX";
            textBoxKX.Size = new Size(318, 39);
            textBoxKX.TabIndex = 1;
            // 
            // textBoxDX
            // 
            textBoxDX.Location = new Point(92, 243);
            textBoxDX.Name = "textBoxDX";
            textBoxDX.Size = new Size(318, 39);
            textBoxDX.TabIndex = 2;
            // 
            // textBoxDY
            // 
            textBoxDY.Location = new Point(484, 243);
            textBoxDY.Name = "textBoxDY";
            textBoxDY.Size = new Size(318, 39);
            textBoxDY.TabIndex = 5;
            // 
            // textBoxKY
            // 
            textBoxKY.Location = new Point(484, 163);
            textBoxKY.Name = "textBoxKY";
            textBoxKY.Size = new Size(318, 39);
            textBoxKY.TabIndex = 4;
            // 
            // textBoxBY
            // 
            textBoxBY.Location = new Point(484, 87);
            textBoxBY.Name = "textBoxBY";
            textBoxBY.Size = new Size(318, 39);
            textBoxBY.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(238, 38);
            label1.Name = "label1";
            label1.Size = new Size(28, 32);
            label1.TabIndex = 6;
            label1.Text = "X";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(633, 38);
            label2.Name = "label2";
            label2.Size = new Size(27, 32);
            label2.TabIndex = 7;
            label2.Text = "Y";
            // 
            // buttonExample
            // 
            buttonExample.Location = new Point(53, 49);
            buttonExample.Name = "buttonExample";
            buttonExample.Size = new Size(422, 46);
            buttonExample.TabIndex = 8;
            buttonExample.Text = "Расчет контрольного примера";
            buttonExample.UseVisualStyleBackColor = true;
            buttonExample.Click += Example_Click;
            // 
            // buttonCalculate
            // 
            buttonCalculate.Location = new Point(53, 125);
            buttonCalculate.Name = "buttonCalculate";
            buttonCalculate.Size = new Size(150, 46);
            buttonCalculate.TabIndex = 9;
            buttonCalculate.Text = "Расчет";
            buttonCalculate.UseVisualStyleBackColor = true;
            buttonCalculate.Click += Calculate_Click;
            // 
            // buttonClear
            // 
            buttonClear.Location = new Point(253, 125);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(222, 46);
            buttonClear.TabIndex = 10;
            buttonClear.Text = "Очистить поля";
            buttonClear.UseVisualStyleBackColor = true;
            buttonClear.Click += Clear_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(textBoxKY);
            groupBox1.Controls.Add(textBoxBX);
            groupBox1.Controls.Add(textBoxKX);
            groupBox1.Controls.Add(textBoxDX);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(textBoxBY);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(textBoxDY);
            groupBox1.Location = new Point(30, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(915, 312);
            groupBox1.TabIndex = 11;
            groupBox1.TabStop = false;
            groupBox1.Text = "Коориданты точек";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(37, 243);
            label5.Name = "label5";
            label5.Size = new Size(31, 32);
            label5.TabIndex = 15;
            label5.Text = "D";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(37, 90);
            label3.Name = "label3";
            label3.Size = new Size(28, 32);
            label3.TabIndex = 14;
            label3.Text = "B";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(37, 166);
            label4.Name = "label4";
            label4.Size = new Size(28, 32);
            label4.TabIndex = 14;
            label4.Text = "K";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(buttonClearY);
            groupBox2.Controls.Add(buttonClearX);
            groupBox2.Controls.Add(buttonExample);
            groupBox2.Controls.Add(buttonCalculate);
            groupBox2.Controls.Add(buttonClear);
            groupBox2.Location = new Point(30, 352);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(915, 207);
            groupBox2.TabIndex = 12;
            groupBox2.TabStop = false;
            groupBox2.Text = "Действия";
            // 
            // buttonClearY
            // 
            buttonClearY.Location = new Point(580, 125);
            buttonClearY.Name = "buttonClearY";
            buttonClearY.Size = new Size(222, 46);
            buttonClearY.TabIndex = 12;
            buttonClearY.Text = "Очистить поля Y";
            buttonClearY.UseVisualStyleBackColor = true;
            buttonClearY.Click += buttonClearY_Click;
            // 
            // buttonClearX
            // 
            buttonClearX.Location = new Point(580, 49);
            buttonClearX.Name = "buttonClearX";
            buttonClearX.Size = new Size(222, 46);
            buttonClearX.TabIndex = 11;
            buttonClearX.Text = "Очистить поля X";
            buttonClearX.UseVisualStyleBackColor = true;
            buttonClearX.Click += buttonClearX_Click;
            // 
            // dataGridViewRes
            // 
            dataGridViewRes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewRes.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3, Column4, Column5, Column6 });
            dataGridViewRes.Location = new Point(1, 583);
            dataGridViewRes.Name = "dataGridViewRes";
            dataGridViewRes.RowHeadersWidth = 82;
            dataGridViewRes.Size = new Size(1745, 483);
            dataGridViewRes.TabIndex = 13;
            // 
            // Column1
            // 
            Column1.HeaderText = "Число точек";
            Column1.MinimumWidth = 10;
            Column1.Name = "Column1";
            Column1.ReadOnly = true;
            Column1.Width = 200;
            // 
            // Column2
            // 
            Column2.HeaderText = "Попадающие точки";
            Column2.MinimumWidth = 10;
            Column2.Name = "Column2";
            Column2.ReadOnly = true;
            Column2.Width = 400;
            // 
            // Column3
            // 
            Column3.HeaderText = "Площадь фигуры";
            Column3.MinimumWidth = 10;
            Column3.Name = "Column3";
            Column3.ReadOnly = true;
            Column3.Width = 300;
            // 
            // Column4
            // 
            Column4.HeaderText = "Площадь Монте-Карло";
            Column4.MinimumWidth = 10;
            Column4.Name = "Column4";
            Column4.ReadOnly = true;
            Column4.Width = 350;
            // 
            // Column5
            // 
            Column5.HeaderText = "Погрешность (%)";
            Column5.MinimumWidth = 10;
            Column5.Name = "Column5";
            Column5.ReadOnly = true;
            Column5.Width = 220;
            // 
            // Column6
            // 
            Column6.HeaderText = "Время вычисления (мс)";
            Column6.MinimumWidth = 10;
            Column6.Name = "Column6";
            Column6.ReadOnly = true;
            Column6.Width = 200;
            // 
            // textBoxSquare
            // 
            textBoxSquare.Location = new Point(1248, 520);
            textBoxSquare.Name = "textBoxSquare";
            textBoxSquare.Size = new Size(454, 39);
            textBoxSquare.TabIndex = 11;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(1014, 520);
            label6.Name = "label6";
            label6.Size = new Size(224, 32);
            label6.TabIndex = 14;
            label6.Text = "Истинная площадь";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(994, 64);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(708, 383);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 15;
            pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlDark;
            ClientSize = new Size(1746, 1066);
            Controls.Add(pictureBox1);
            Controls.Add(label6);
            Controls.Add(textBoxSquare);
            Controls.Add(dataGridViewRes);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximumSize = new Size(1772, 1137);
            MinimumSize = new Size(1772, 1137);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Расчет площади фигуры методом Монте-Карло";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridViewRes).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBoxBX;
        private TextBox textBoxKX;
        private TextBox textBoxDX;
        private TextBox textBoxDY;
        private TextBox textBoxKY;
        private TextBox textBoxBY;
        private TextBox textBoxSquare;
        private Label label1;
        private Label label2;
        private Button buttonExample;
        private Button buttonCalculate;
        private Button buttonClear;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private DataGridView dataGridViewRes;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
        private DataGridViewTextBoxColumn Column5;
        private DataGridViewTextBoxColumn Column6;
        private Label label5;
        private Label label3;
        private Label label4;
        private Label label6;
        private PictureBox pictureBox1;
        private Button buttonClearY;
        private Button buttonClearX;
    }
}
